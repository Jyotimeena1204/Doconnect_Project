# DoConnect Backend - Complete API Documentation

## 🎯 Overview
DoConnect is a discussion platform backend built with **Spring Boot microservices architecture**. This project consists of three independent services that work together to provide a complete discussion platform similar to Stack Overflow or Reddit.

---

## 🏗️ Architecture

### Microservices
1. **Auth Service** (Port 8081) - User authentication and management
2. **Discussion Service** (Port 8082) - Questions, answers, likes, and comments
3. **Interaction Service** (Port 8083) - Chat and notifications

### Technology Stack
- **Framework:** Spring Boot 3.2.0
- **Language:** Java 17
- **Database:** MySQL/MariaDB 10.11
- **Security:** Spring Security + JWT
- **ORM:** Spring Data JPA / Hibernate
- **Build Tool:** Maven 3.8.7

---

## 🚀 Getting Started

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL/MariaDB

### Quick Start

#### 1. Start All Services
```bash
cd /app/backend-java
./start-all-services.sh
```

#### 2. Start Individual Services
```bash
# Auth Service
./start-auth-service.sh

# Discussion Service
./start-discussion-service.sh

# Interaction Service
./start-interaction-service.sh
```

#### 3. Build Services
```bash
# Build all services
cd auth-service && mvn clean package -DskipTests
cd ../discussion-service && mvn clean package -DskipTests
cd ../interaction-service && mvn clean package -DskipTests
```

---

## 📡 API Endpoints

### 🔐 Auth Service (Port 8081)
**Base URL:** `http://localhost:8081/api/auth`

#### User Authentication

**POST /register** - Register a new user
```bash
curl -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "email": "john@example.com",
    "password": "password123"
  }'
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9...",
  "type": "Bearer",
  "userId": 1,
  "username": "johndoe",
  "email": "john@example.com",
  "role": "USER"
}
```

**POST /login** - Login user
```bash
curl -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "usernameOrEmail": "johndoe",
    "password": "password123"
  }'
```

**GET /profile** - Get user profile (requires authentication)
```bash
curl -X GET http://localhost:8081/api/auth/profile \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

#### Admin Operations

**GET /admin/users** - Get all users (Admin only)
```bash
curl -X GET http://localhost:8081/api/auth/admin/users \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

**PUT /admin/users/{userId}/activate** - Activate user
```bash
curl -X PUT http://localhost:8081/api/auth/admin/users/1/activate \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

**PUT /admin/users/{userId}/deactivate** - Deactivate user
```bash
curl -X PUT http://localhost:8081/api/auth/admin/users/1/deactivate \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

**GET /health** - Health check
```bash
curl -X GET http://localhost:8081/api/auth/health
```

---

### 💬 Discussion Service (Port 8082)
**Base URL:** `http://localhost:8082/api/discussion`

#### Questions

**POST /questions** - Create a new question
```bash
curl -X POST http://localhost:8082/api/discussion/questions \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "title": "How to use Spring Boot?",
    "content": "I am new to Spring Boot and need help getting started."
  }'
```

**GET /questions** - Get all questions
```bash
curl -X GET http://localhost:8082/api/discussion/questions
```

**GET /questions/approved** - Get approved questions
```bash
curl -X GET http://localhost:8082/api/discussion/questions/approved
```

**GET /questions/pending** - Get pending questions
```bash
curl -X GET http://localhost:8082/api/discussion/questions/pending
```

**GET /questions/{id}** - Get question by ID
```bash
curl -X GET http://localhost:8082/api/discussion/questions/1
```

**GET /questions/user/{userId}** - Get questions by user
```bash
curl -X GET http://localhost:8082/api/discussion/questions/user/1
```

**GET /questions/search?keyword={keyword}** - Search questions
```bash
curl -X GET "http://localhost:8082/api/discussion/questions/search?keyword=spring"
```

**PUT /questions/{id}/approve** - Approve question (Admin)
```bash
curl -X PUT http://localhost:8082/api/discussion/questions/1/approve
```

**PUT /questions/{id}/reject** - Reject question (Admin)
```bash
curl -X PUT http://localhost:8082/api/discussion/questions/1/reject
```

**PUT /questions/{id}/close** - Close question (Admin)
```bash
curl -X PUT http://localhost:8082/api/discussion/questions/1/close
```

**DELETE /questions/{id}** - Delete question
```bash
curl -X DELETE http://localhost:8082/api/discussion/questions/1
```

#### Answers

**POST /answers** - Create an answer
```bash
curl -X POST http://localhost:8082/api/discussion/answers \
  -H "Content-Type: application/json" \
  -d '{
    "questionId": 1,
    "userId": 2,
    "content": "You can start with Spring Initializr..."
  }'
```

**GET /answers** - Get all answers
```bash
curl -X GET http://localhost:8082/api/discussion/answers
```

**GET /answers/question/{questionId}** - Get answers for a question
```bash
curl -X GET http://localhost:8082/api/discussion/answers/question/1
```

**GET /answers/pending** - Get pending answers
```bash
curl -X GET http://localhost:8082/api/discussion/answers/pending
```

**GET /answers/{id}** - Get answer by ID
```bash
curl -X GET http://localhost:8082/api/discussion/answers/1
```

**PUT /answers/{id}/approve** - Approve answer (Admin)
```bash
curl -X PUT http://localhost:8082/api/discussion/answers/1/approve
```

**PUT /answers/{id}/reject** - Reject answer (Admin)
```bash
curl -X PUT http://localhost:8082/api/discussion/answers/1/reject
```

**DELETE /answers/{id}** - Delete answer
```bash
curl -X DELETE http://localhost:8082/api/discussion/answers/1
```

#### Likes

**POST /likes** - Add a like
```bash
curl -X POST http://localhost:8082/api/discussion/likes \
  -H "Content-Type: application/json" \
  -d '{
    "answerId": 1,
    "userId": 3
  }'
```

**DELETE /likes/answer/{answerId}/user/{userId}** - Remove like
```bash
curl -X DELETE http://localhost:8082/api/discussion/likes/answer/1/user/3
```

**GET /likes/answer/{answerId}** - Get all likes for an answer
```bash
curl -X GET http://localhost:8082/api/discussion/likes/answer/1
```

**GET /likes/answer/{answerId}/count** - Get likes count
```bash
curl -X GET http://localhost:8082/api/discussion/likes/answer/1/count
```

**GET /likes/answer/{answerId}/user/{userId}/check** - Check if user liked
```bash
curl -X GET http://localhost:8082/api/discussion/likes/answer/1/user/3/check
```

#### Comments

**POST /comments** - Add a comment
```bash
curl -X POST http://localhost:8082/api/discussion/comments \
  -H "Content-Type: application/json" \
  -d '{
    "answerId": 1,
    "userId": 4,
    "content": "Great explanation!"
  }'
```

**GET /comments/answer/{answerId}** - Get comments for an answer
```bash
curl -X GET http://localhost:8082/api/discussion/comments/answer/1
```

**GET /comments/user/{userId}** - Get comments by user
```bash
curl -X GET http://localhost:8082/api/discussion/comments/user/4
```

**GET /comments/{id}** - Get comment by ID
```bash
curl -X GET http://localhost:8082/api/discussion/comments/1
```

**GET /comments/answer/{answerId}/count** - Get comments count
```bash
curl -X GET http://localhost:8082/api/discussion/comments/answer/1/count
```

**DELETE /comments/{id}** - Delete comment
```bash
curl -X DELETE http://localhost:8082/api/discussion/comments/1
```

**GET /questions/health** - Health check
```bash
curl -X GET http://localhost:8082/api/discussion/questions/health
```

---

### 💌 Interaction Service (Port 8083)
**Base URL:** `http://localhost:8083/api/interaction`

#### Messages (Chat)

**POST /messages** - Send a message
```bash
curl -X POST http://localhost:8083/api/interaction/messages \
  -H "Content-Type: application/json" \
  -d '{
    "senderId": 1,
    "receiverId": 2,
    "content": "Hello! Can you help me with Spring Boot?"
  }'
```

**GET /messages** - Get all messages
```bash
curl -X GET http://localhost:8083/api/interaction/messages
```

**GET /messages/user/{userId}** - Get all messages for a user
```bash
curl -X GET http://localhost:8083/api/interaction/messages/user/1
```

**GET /messages/conversation?userId1={id1}&userId2={id2}** - Get conversation
```bash
curl -X GET "http://localhost:8083/api/interaction/messages/conversation?userId1=1&userId2=2"
```

**GET /messages/unread/{userId}** - Get unread messages
```bash
curl -X GET http://localhost:8083/api/interaction/messages/unread/1
```

**GET /messages/unread/{userId}/count** - Get unread count
```bash
curl -X GET http://localhost:8083/api/interaction/messages/unread/1/count
```

**GET /messages/{id}** - Get message by ID
```bash
curl -X GET http://localhost:8083/api/interaction/messages/1
```

**PUT /messages/{id}/read** - Mark message as read
```bash
curl -X PUT http://localhost:8083/api/interaction/messages/1/read
```

**PUT /messages/user/{userId}/read-all** - Mark all as read
```bash
curl -X PUT http://localhost:8083/api/interaction/messages/user/1/read-all
```

**DELETE /messages/{id}** - Delete message
```bash
curl -X DELETE http://localhost:8083/api/interaction/messages/1
```

#### Notifications

**POST /notifications** - Create a notification
```bash
curl -X POST http://localhost:8083/api/interaction/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "type": "NEW_QUESTION",
    "content": "New question posted: How to use Spring Boot?"
  }'
```

**Notification Types:**
- `NEW_QUESTION` - New question posted
- `NEW_ANSWER` - New answer posted
- `NEW_COMMENT` - New comment added
- `QUESTION_APPROVED` - Question approved by admin
- `QUESTION_REJECTED` - Question rejected by admin
- `ANSWER_APPROVED` - Answer approved by admin
- `ANSWER_REJECTED` - Answer rejected by admin

**GET /notifications** - Get all notifications
```bash
curl -X GET http://localhost:8083/api/interaction/notifications
```

**GET /notifications/user/{userId}** - Get user notifications
```bash
curl -X GET http://localhost:8083/api/interaction/notifications/user/1
```

**GET /notifications/user/{userId}/unread** - Get unread notifications
```bash
curl -X GET http://localhost:8083/api/interaction/notifications/user/1/unread
```

**GET /notifications/user/{userId}/unread/count** - Get unread count
```bash
curl -X GET http://localhost:8083/api/interaction/notifications/user/1/unread/count
```

**GET /notifications/type/{type}** - Get notifications by type
```bash
curl -X GET http://localhost:8083/api/interaction/notifications/type/NEW_QUESTION
```

**GET /notifications/{id}** - Get notification by ID
```bash
curl -X GET http://localhost:8083/api/interaction/notifications/1
```

**PUT /notifications/{id}/read** - Mark notification as read
```bash
curl -X PUT http://localhost:8083/api/interaction/notifications/1/read
```

**PUT /notifications/user/{userId}/read-all** - Mark all as read
```bash
curl -X PUT http://localhost:8083/api/interaction/notifications/user/1/read-all
```

**DELETE /notifications/{id}** - Delete notification
```bash
curl -X DELETE http://localhost:8083/api/interaction/notifications/1
```

**GET /messages/health** - Health check
```bash
curl -X GET http://localhost:8083/api/interaction/messages/health
```

---

## 📊 Database Schema

### Auth Service Database (doconnect_auth)

#### users
```sql
CREATE TABLE users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Discussion Service Database (doconnect_discussion)

#### questions
```sql
CREATE TABLE questions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  status ENUM('PENDING', 'APPROVED', 'REJECTED', 'CLOSED') NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### answers
```sql
CREATE TABLE answers (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  question_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  content TEXT NOT NULL,
  status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
  likes_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### likes
```sql
CREATE TABLE likes (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  answer_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_like (answer_id, user_id)
);
```

#### comments
```sql
CREATE TABLE comments (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  answer_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Interaction Service Database (doconnect_interaction)

#### messages
```sql
CREATE TABLE messages (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  sender_id BIGINT NOT NULL,
  receiver_id BIGINT NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### notifications
```sql
CREATE TABLE notifications (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  type ENUM('NEW_QUESTION', 'NEW_ANSWER', 'NEW_COMMENT', 'QUESTION_APPROVED', 'QUESTION_REJECTED', 'ANSWER_APPROVED', 'ANSWER_REJECTED') NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🧪 Testing Examples

### Complete User Flow Test

```bash
# 1. Register a user
REGISTER_RESPONSE=$(curl -s -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}')

# Extract token
TOKEN=$(echo $REGISTER_RESPONSE | grep -o '"token":"[^"]*"' | cut -d'"' -f4)

echo "User registered! Token: $TOKEN"

# 2. Create a question
QUESTION_RESPONSE=$(curl -s -X POST http://localhost:8082/api/discussion/questions \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"title":"Test Question","content":"This is a test question"}')

echo "Question created: $QUESTION_RESPONSE"

# 3. Get all questions
curl -s -X GET http://localhost:8082/api/discussion/questions/approved

# 4. Send a message
curl -s -X POST http://localhost:8083/api/interaction/messages \
  -H "Content-Type: application/json" \
  -d '{"senderId":1,"receiverId":2,"content":"Hello!"}'

# 5. Create a notification
curl -s -X POST http://localhost:8083/api/interaction/notifications \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"type":"NEW_QUESTION","content":"New question posted"}'
```

---

## 📝 Configuration

### Application Properties

#### Auth Service (`application.properties`)
```properties
server.port=8081
server.servlet.context-path=/api/auth
spring.datasource.url=jdbc:mysql://localhost:3306/doconnect_auth
spring.datasource.username=root
spring.datasource.password=
jwt.secret=doconnect-secret-key-for-jwt-authentication-very-long-secret-key-2025
jwt.expiration=86400000
```

#### Discussion Service (`application.properties`)
```properties
server.port=8082
server.servlet.context-path=/api/discussion
spring.datasource.url=jdbc:mysql://localhost:3306/doconnect_discussion
spring.datasource.username=root
spring.datasource.password=
```

#### Interaction Service (`application.properties`)
```properties
server.port=8083
server.servlet.context-path=/api/interaction
spring.datasource.url=jdbc:mysql://localhost:3306/doconnect_interaction
spring.datasource.username=root
spring.datasource.password=
```

---

## 🐛 Troubleshooting

### Check Service Status
```bash
# Check if services are running
ps aux | grep java

# Check logs
tail -f /tmp/auth-service.log
tail -f /tmp/discussion-service.log
tail -f /tmp/interaction-service.log
```

### Common Issues

**MySQL Connection Error:**
```bash
# Start MySQL
service mariadb start

# Verify MySQL is running
service mariadb status
```

**Port Already in Use:**
```bash
# Find process using port
lsof -i :8081

# Kill process
kill -9 <PID>
```

**Build Errors:**
```bash
# Clean and rebuild
cd /app/backend-java/auth-service
mvn clean install -U
```

---

## 📦 Project Structure

```
/app/backend-java/
├── auth-service/
│   ├── src/main/java/com/doconnect/authservice/
│   │   ├── controller/     # REST Controllers
│   │   ├── service/        # Business Logic
│   │   ├── repository/     # Data Access
│   │   ├── model/          # Entity Models
│   │   ├── dto/            # Data Transfer Objects
│   │   ├── security/       # JWT & Security
│   │   └── config/         # Configuration
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── discussion-service/
│   ├── src/main/java/com/doconnect/discussionservice/
│   │   ├── controller/     # Question, Answer, Like, Comment Controllers
│   │   ├── service/        # Business Logic
│   │   ├── repository/     # Data Access
│   │   ├── model/          # Entity Models
│   │   └── dto/            # Data Transfer Objects
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── interaction-service/
│   ├── src/main/java/com/doconnect/interactionservice/
│   │   ├── controller/     # Message & Notification Controllers
│   │   ├── service/        # Business Logic
│   │   ├── repository/     # Data Access
│   │   ├── model/          # Entity Models
│   │   └── dto/            # Data Transfer Objects
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── start-auth-service.sh
├── start-discussion-service.sh
├── start-interaction-service.sh
└── start-all-services.sh
```

---

## 🎓 Features Summary

### ✅ Auth Service
- ✅ User Registration with validation
- ✅ User Login with JWT tokens
- ✅ Password encryption (BCrypt)
- ✅ Role-based access control (USER/ADMIN)
- ✅ User profile management
- ✅ Admin user management (activate/deactivate)
- ✅ JWT token generation and validation
- ✅ Spring Security integration

### ✅ Discussion Service
- ✅ Question CRUD operations
- ✅ Answer management
- ✅ Like/Unlike functionality
- ✅ Comment system
- ✅ Search functionality by keywords
- ✅ Admin approval workflows (questions & answers)
- ✅ Close/reject discussions
- ✅ Status tracking (PENDING/APPROVED/REJECTED/CLOSED)

### ✅ Interaction Service
- ✅ Chat/messaging between users
- ✅ Conversation history
- ✅ Unread message tracking
- ✅ Notification system
- ✅ Multiple notification types
- ✅ Read/unread status
- ✅ Mark all as read functionality

---

## 🚀 Next Steps

1. **Frontend Integration**: Connect React frontend with these APIs
2. **WebSocket**: Add real-time chat using WebSocket
3. **File Upload**: Add file/image upload for questions and answers
4. **Email Notifications**: Send email notifications for important events
5. **Search Enhancement**: Implement full-text search with Elasticsearch
6. **API Gateway**: Add API Gateway for centralized routing
7. **Docker**: Containerize all services
8. **Testing**: Add comprehensive unit and integration tests
9. **API Documentation**: Add Swagger/OpenAPI documentation
10. **Monitoring**: Add service monitoring with Actuator

---

## 📞 Support

For issues or questions:
- Check logs in `/tmp/` directory
- Verify MySQL is running
- Ensure all services are built successfully
- Check port availability (8081, 8082, 8083)

---

## 📄 License

This project is created for educational purposes as per the DoConnect Capstone project requirements.

---

**Built with ❤️ using Spring Boot**
