package com.doconnect.interactionservice.repository;

import com.doconnect.interactionservice.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Notification> findByUserIdAndIsReadFalseOrderByCreatedAtDesc(Long userId);
    Integer countByUserIdAndIsReadFalse(Long userId);
    List<Notification> findByTypeOrderByCreatedAtDesc(Notification.Type type);
}