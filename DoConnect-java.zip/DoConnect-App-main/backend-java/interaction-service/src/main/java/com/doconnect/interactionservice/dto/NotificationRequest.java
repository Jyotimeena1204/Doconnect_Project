package com.doconnect.interactionservice.dto;

import com.doconnect.interactionservice.model.Notification;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {
    
    @NotNull(message = "User ID is required")
    private Long userId;
    
    @NotNull(message = "Type is required")
    private Notification.Type type;
    
    @NotBlank(message = "Content is required")
    private String content;
}