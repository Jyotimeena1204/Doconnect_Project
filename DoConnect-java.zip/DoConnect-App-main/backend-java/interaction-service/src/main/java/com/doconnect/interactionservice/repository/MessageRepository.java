package com.doconnect.interactionservice.repository;

import com.doconnect.interactionservice.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {
    List<Message> findBySenderIdOrReceiverIdOrderByCreatedAtDesc(Long senderId, Long receiverId);
    
    @Query("SELECT m FROM Message m WHERE (m.senderId = ?1 AND m.receiverId = ?2) OR (m.senderId = ?2 AND m.receiverId = ?1) ORDER BY m.createdAt ASC")
    List<Message> findConversationBetweenUsers(Long userId1, Long userId2);
    
    List<Message> findByReceiverIdAndIsReadFalse(Long receiverId);
    
    Integer countByReceiverIdAndIsReadFalse(Long receiverId);
}