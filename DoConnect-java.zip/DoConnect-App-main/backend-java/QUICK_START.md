# DoConnect Backend - Quick Start Guide

## 🚀 All Services Successfully Built!

### ✅ Build Status
- **Auth Service**: ✅ Built successfully
- **Discussion Service**: ✅ Built successfully
- **Interaction Service**: ✅ Built successfully

All JAR files have been created and are ready to run.

---

## 📝 Before Starting Services

### Fix MySQL Authentication (IMPORTANT)

Run these commands to allow root access without password:

```bash
# Start MySQL
service mariadb start

# Fix MySQL authentication
mariadb -u root -e "
  CREATE USER IF NOT EXISTS 'root'@'localhost' IDENTIFIED BY '';
  GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
  FLUSH PRIVILEGES;
"

# Verify databases exist
mariadb -u root -e "SHOW DATABASES;"
```

You should see these databases:
- doconnect_auth
- doconnect_discussion
- doconnect_interaction

---

## 🏃 Starting Services

### Option 1: Start All Services Together
```bash
cd /app/backend-java
chmod +x *.sh
./start-all-services.sh
```

### Option 2: Start Services Individually

**Terminal 1 - Auth Service:**
```bash
cd /app/backend-java/auth-service
java -jar target/auth-service-1.0.0.jar
```

**Terminal 2 - Discussion Service:**
```bash
cd /app/backend-java/discussion-service
java -jar target/discussion-service-1.0.0.jar
```

**Terminal 3 - Interaction Service:**
```bash
cd /app/backend-java/interaction-service
java -jar target/interaction-service-1.0.0.jar
```

---

## 🧪 Testing the Services

### 1. Health Checks
```bash
# Auth Service
curl http://localhost:8081/api/auth/health

# Discussion Service
curl http://localhost:8082/api/discussion/questions/health

# Interaction Service
curl http://localhost:8083/api/interaction/messages/health
```

Expected response:
```json
{
  "status": "UP",
  "service": "Auth Service"
}
```

### 2. Complete Flow Test

```bash
# Step 1: Register a user
curl -X POST http://localhost:8081/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }'

# Step 2: Login
curl -X POST http://localhost:8081/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "usernameOrEmail": "testuser",
    "password": "password123"
  }'

# Step 3: Create a question
curl -X POST http://localhost:8082/api/discussion/questions \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "title": "How to use Spring Boot?",
    "content": "I need help with Spring Boot setup"
  }'

# Step 4: Get all questions
curl http://localhost:8082/api/discussion/questions

# Step 5: Send a message
curl -X POST http://localhost:8083/api/interaction/messages \
  -H "Content-Type: application/json" \
  -d '{
    "senderId": 1,
    "receiverId": 2,
    "content": "Hello! Can you help me?"
  }'

# Step 6: Create a notification
curl -X POST http://localhost:8083/api/interaction/notifications \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "type": "NEW_QUESTION",
    "content": "New question: How to use Spring Boot?"
  }'
```

---

## 🐛 Troubleshooting

### Services Not Starting?

1. **Check MySQL is running:**
```bash
service mariadb status
service mariadb start
```

2. **Check MySQL authentication:**
```bash
mariadb -u root -e "SELECT USER();"
```

3. **View service logs:**
```bash
# If using start-all-services.sh
tail -f /tmp/auth-service.log
tail -f /tmp/discussion-service.log
tail -f /tmp/interaction-service.log

# Or check terminal output if running directly
```

4. **Check if ports are available:**
```bash
# Check if ports are in use
lsof -i :8081
lsof -i :8082
lsof -i :8083
```

5. **Kill existing processes:**
```bash
# Find Java processes
ps aux | grep java

# Kill specific process
kill -9 <PID>

# Or kill all Java processes
pkill -f java
```

### Common Errors

**Error: "Access denied for user 'root'@'localhost'"**
- Solution: Run the MySQL authentication fix commands above

**Error: "Address already in use"**
- Solution: Another service is using the port, kill it or use a different port

**Error: "Database not found"**
- Solution: Create the databases manually:
```bash
mariadb -u root <<EOF
CREATE DATABASE IF NOT EXISTS doconnect_auth;
CREATE DATABASE IF NOT EXISTS doconnect_discussion;
CREATE DATABASE IF NOT EXISTS doconnect_interaction;
EOF
```

---

## 📚 Full Documentation

See `/app/backend-java/API_DOCUMENTATION.md` for:
- Complete API endpoint reference
- Request/response examples
- Database schema
- Architecture details
- Advanced configuration

---

## 🎯 Service URLs

Once all services are running:

- **Auth Service:** http://localhost:8081/api/auth
- **Discussion Service:** http://localhost:8082/api/discussion
- **Interaction Service:** http://localhost:8083/api/interaction

---

## 📦 Project Structure

```
/app/backend-java/
├── auth-service/
│   └── target/auth-service-1.0.0.jar ✅
├── discussion-service/
│   └── target/discussion-service-1.0.0.jar ✅
├── interaction-service/
│   └── target/interaction-service-1.0.0.jar ✅
├── start-all-services.sh
├── start-auth-service.sh
├── start-discussion-service.sh
├── start-interaction-service.sh
└── API_DOCUMENTATION.md
```

---

## ✨ What's Included

### Auth Service
- ✅ User registration and login
- ✅ JWT token generation
- ✅ Password encryption
- ✅ Admin user management
- ✅ Role-based access control

### Discussion Service
- ✅ Question CRUD operations
- ✅ Answer management
- ✅ Like/unlike functionality
- ✅ Comment system
- ✅ Search by keywords
- ✅ Admin approval workflows

### Interaction Service
- ✅ Chat/messaging system
- ✅ Conversation history
- ✅ Notification system
- ✅ Read/unread tracking
- ✅ Multiple notification types

---

## 🎓 Next Steps

1. Fix MySQL authentication using the commands above
2. Start all services
3. Test with the provided curl commands
4. Connect your React frontend
5. Build amazing features!

---

**Happy Coding! 🚀**
