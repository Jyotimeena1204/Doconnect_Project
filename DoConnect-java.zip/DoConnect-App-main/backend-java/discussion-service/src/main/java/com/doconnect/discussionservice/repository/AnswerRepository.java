package com.doconnect.discussionservice.repository;

import com.doconnect.discussionservice.model.Answer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AnswerRepository extends JpaRepository<Answer, Long> {
    List<Answer> findByQuestionId(Long questionId);
    List<Answer> findByUserId(Long userId);
    List<Answer> findByQuestionIdAndStatus(Long questionId, Answer.Status status);
    List<Answer> findByStatus(Answer.Status status);
}