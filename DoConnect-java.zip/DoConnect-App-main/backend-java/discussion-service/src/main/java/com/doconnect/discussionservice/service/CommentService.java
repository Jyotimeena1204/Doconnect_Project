package com.doconnect.discussionservice.service;

import com.doconnect.discussionservice.dto.CommentRequest;
import com.doconnect.discussionservice.model.Comment;
import com.doconnect.discussionservice.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CommentService {
    
    @Autowired
    private CommentRepository commentRepository;
    
    public Comment createComment(CommentRequest request) {
        Comment comment = new Comment();
        comment.setAnswerId(request.getAnswerId());
        comment.setUserId(request.getUserId());
        comment.setContent(request.getContent());
        return commentRepository.save(comment);
    }
    
    public List<Comment> getCommentsByAnswerId(Long answerId) {
        return commentRepository.findByAnswerId(answerId);
    }
    
    public List<Comment> getCommentsByUserId(Long userId) {
        return commentRepository.findByUserId(userId);
    }
    
    public Comment getCommentById(Long id) {
        return commentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Comment not found with id: " + id));
    }
    
    public Integer getCommentsCount(Long answerId) {
        return commentRepository.countByAnswerId(answerId);
    }
    
    @Transactional
    public void deleteComment(Long id) {
        commentRepository.deleteById(id);
    }
}