package com.doconnect.discussionservice.service;

import com.doconnect.discussionservice.dto.LikeRequest;
import com.doconnect.discussionservice.model.Like;
import com.doconnect.discussionservice.repository.LikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LikeService {
    
    @Autowired
    private LikeRepository likeRepository;
    
    @Autowired
    private AnswerService answerService;
    
    @Transactional
    public Like addLike(LikeRequest request) {
        // Check if already liked
        if (likeRepository.existsByAnswerIdAndUserId(request.getAnswerId(), request.getUserId())) {
            throw new RuntimeException("User has already liked this answer");
        }
        
        Like like = new Like();
        like.setAnswerId(request.getAnswerId());
        like.setUserId(request.getUserId());
        Like savedLike = likeRepository.save(like);
        
        // Update answer likes count
        answerService.updateLikesCount(request.getAnswerId(), 1);
        
        return savedLike;
    }
    
    @Transactional
    public void removeLike(Long answerId, Long userId) {
        Like like = likeRepository.findByAnswerIdAndUserId(answerId, userId)
                .orElseThrow(() -> new RuntimeException("Like not found"));
        
        likeRepository.delete(like);
        
        // Update answer likes count
        answerService.updateLikesCount(answerId, -1);
    }
    
    public List<Like> getLikesByAnswerId(Long answerId) {
        return likeRepository.findByAnswerId(answerId);
    }
    
    public Integer getLikesCount(Long answerId) {
        return likeRepository.countByAnswerId(answerId);
    }
    
    public Boolean hasUserLiked(Long answerId, Long userId) {
        return likeRepository.existsByAnswerIdAndUserId(answerId, userId);
    }
}