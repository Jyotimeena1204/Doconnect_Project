package com.doconnect.discussionservice.service;

import com.doconnect.discussionservice.dto.QuestionRequest;
import com.doconnect.discussionservice.model.Question;
import com.doconnect.discussionservice.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class QuestionService {
    
    @Autowired
    private QuestionRepository questionRepository;
    
    public Question createQuestion(QuestionRequest request) {
        Question question = new Question();
        question.setUserId(request.getUserId());
        question.setTitle(request.getTitle());
        question.setContent(request.getContent());
        question.setStatus(Question.Status.PENDING);
        return questionRepository.save(question);
    }
    
    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }
    
    public List<Question> getApprovedQuestions() {
        return questionRepository.findByStatusOrderByCreatedAtDesc(Question.Status.APPROVED);
    }
    
    public List<Question> getPendingQuestions() {
        return questionRepository.findByStatus(Question.Status.PENDING);
    }
    
    public Question getQuestionById(Long id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Question not found with id: " + id));
    }
    
    public List<Question> getQuestionsByUserId(Long userId) {
        return questionRepository.findByUserId(userId);
    }
    
    public List<Question> searchQuestions(String keyword) {
        return questionRepository.findByTitleContainingOrContentContaining(keyword, keyword);
    }
    
    @Transactional
    public Question approveQuestion(Long id) {
        Question question = getQuestionById(id);
        question.setStatus(Question.Status.APPROVED);
        return questionRepository.save(question);
    }
    
    @Transactional
    public Question rejectQuestion(Long id) {
        Question question = getQuestionById(id);
        question.setStatus(Question.Status.REJECTED);
        return questionRepository.save(question);
    }
    
    @Transactional
    public Question closeQuestion(Long id) {
        Question question = getQuestionById(id);
        question.setStatus(Question.Status.CLOSED);
        return questionRepository.save(question);
    }
    
    @Transactional
    public void deleteQuestion(Long id) {
        questionRepository.deleteById(id);
    }
}