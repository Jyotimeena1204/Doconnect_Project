package com.doconnect.discussionservice.service;

import com.doconnect.discussionservice.dto.AnswerRequest;
import com.doconnect.discussionservice.model.Answer;
import com.doconnect.discussionservice.repository.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AnswerService {
    
    @Autowired
    private AnswerRepository answerRepository;
    
    public Answer createAnswer(AnswerRequest request) {
        Answer answer = new Answer();
        answer.setQuestionId(request.getQuestionId());
        answer.setUserId(request.getUserId());
        answer.setContent(request.getContent());
        answer.setStatus(Answer.Status.PENDING);
        answer.setLikesCount(0);
        return answerRepository.save(answer);
    }
    
    public List<Answer> getAllAnswers() {
        return answerRepository.findAll();
    }
    
    public List<Answer> getAnswersByQuestionId(Long questionId) {
        return answerRepository.findByQuestionIdAndStatus(questionId, Answer.Status.APPROVED);
    }
    
    public List<Answer> getPendingAnswers() {
        return answerRepository.findByStatus(Answer.Status.PENDING);
    }
    
    public Answer getAnswerById(Long id) {
        return answerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Answer not found with id: " + id));
    }
    
    public List<Answer> getAnswersByUserId(Long userId) {
        return answerRepository.findByUserId(userId);
    }
    
    @Transactional
    public Answer approveAnswer(Long id) {
        Answer answer = getAnswerById(id);
        answer.setStatus(Answer.Status.APPROVED);
        return answerRepository.save(answer);
    }
    
    @Transactional
    public Answer rejectAnswer(Long id) {
        Answer answer = getAnswerById(id);
        answer.setStatus(Answer.Status.REJECTED);
        return answerRepository.save(answer);
    }
    
    @Transactional
    public void deleteAnswer(Long id) {
        answerRepository.deleteById(id);
    }
    
    @Transactional
    public Answer updateLikesCount(Long answerId, Integer delta) {
        Answer answer = getAnswerById(answerId);
        answer.setLikesCount(answer.getLikesCount() + delta);
        return answerRepository.save(answer);
    }
}