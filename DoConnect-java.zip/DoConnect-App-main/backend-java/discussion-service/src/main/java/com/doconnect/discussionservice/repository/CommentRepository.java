package com.doconnect.discussionservice.repository;

import com.doconnect.discussionservice.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByAnswerId(Long answerId);
    List<Comment> findByUserId(Long userId);
    Integer countByAnswerId(Long answerId);
}