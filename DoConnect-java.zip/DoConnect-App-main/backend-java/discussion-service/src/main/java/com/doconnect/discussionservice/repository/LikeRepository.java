package com.doconnect.discussionservice.repository;

import com.doconnect.discussionservice.model.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public interface LikeRepository extends JpaRepository<Like, Long> {
    Optional<Like> findByAnswerIdAndUserId(Long answerId, Long userId);
    Boolean existsByAnswerIdAndUserId(Long answerId, Long userId);
    List<Like> findByAnswerId(Long answerId);
    Integer countByAnswerId(Long answerId);
    void deleteByAnswerIdAndUserId(Long answerId, Long userId);
}