package com.doconnect.discussionservice.repository;

import com.doconnect.discussionservice.model.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByUserId(Long userId);
    List<Question> findByStatus(Question.Status status);
    List<Question> findByTitleContainingOrContentContaining(String title, String content);
    List<Question> findByStatusOrderByCreatedAtDesc(Question.Status status);
}